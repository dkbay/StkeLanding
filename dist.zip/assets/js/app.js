// App javascript goes here
require("./now-ui-kit.js");

var test = "test";
